"""Figures: loss curves (Fig. 4), test forecasts (Fig. 5) and two supplementary plots."""
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from .config import TEST

COLORS = dict(obs="#1f77b4", fc="#ff7f0e", val="#d62728")
LETTERS = "abcdefghi"


def _save(fig, path, dpi):
    fig.tight_layout()
    fig.savefig(path, dpi=dpi, bbox_inches="tight")
    plt.close(fig)


def _legend_below(fig, ax):
    handles, labels = ax.get_legend_handles_labels()
    if handles:
        fig.legend(handles, labels, loc="upper center", bbox_to_anchor=(0.5, 0.0),
                   ncol=len(labels), frameon=False, fontsize=11)


def station_panels(names, draw, grid_path, single_dir, tag, dpi):
    """One figure per station plus a 3 x 3 grid with panel letters."""
    for name in names:
        fig, ax = plt.subplots(figsize=(10, 5.5))
        draw(ax, name, name)
        _legend_below(fig, ax)
        _save(fig, os.path.join(single_dir, f"{name.replace(chr(39), '').replace(' ', '')}_{tag}.png"), dpi)
    fig, axes = plt.subplots(3, 3, figsize=(16, 12))
    axes = list(axes.flat)
    for k, (ax, name) in enumerate(zip(axes, names)):
        draw(ax, name, f"({LETTERS[k]}) {name}")
    for ax in axes[len(names):]:
        ax.axis("off")
    _legend_below(fig, axes[0])
    _save(fig, grid_path, dpi)


def loss_panel(histories):
    def draw(ax, name, title):
        h = histories[name]
        ax.plot(h["loss"], color=COLORS["obs"], lw=1.8, label="Training loss")
        ax.plot(h["val_loss"], color=COLORS["val"], lw=1.8, label="Validation loss (2022)")
        ax.set_xlim(0, len(h["loss"]))
        ax.set_xlabel("Epoch")
        ax.set_ylabel("MSE (normalised)")
        ax.set_title(title)
        ax.grid(alpha=0.3)
    return draw


def forecast_panel(monthly_all, test_pred):
    def draw(ax, name, title):
        mo, p = monthly_all[name], test_pred[name]
        ax.axvspan(pd.Timestamp(TEST[0]), pd.Timestamp("2024-12-31"), color="grey", alpha=0.12)
        ax.plot(mo.index, mo.values, color=COLORS["obs"], lw=1.0, label="Observed SST")
        ax.plot(p.index, p.values, color=COLORS["fc"], lw=1.8, label="One-step-ahead forecast (2023\u20132024)")
        ax.set_ylabel("SST (\u00b0C)")
        ax.set_title(title)
        ax.grid(alpha=0.3)
    return draw


def variability_scatter(merged, corr_rows, path, dpi):
    fig, axes = plt.subplots(2, 2, figsize=(12, 10))
    for ax, row in zip(axes.flat, corr_rows):
        var, acc = row["Relationship"].split(" vs ")
        ax.scatter(merged[var], merged[acc], s=60, color=COLORS["obs"], edgecolor="k", zorder=3)
        for _, st in merged.iterrows():
            ax.annotate(st["Station"], (st[var], st[acc]), fontsize=8, xytext=(4, 4), textcoords="offset points")
        coef = np.polyfit(merged[var], merged[acc], 1)
        xs = np.linspace(merged[var].min(), merged[var].max(), 50)
        ax.plot(xs, np.polyval(coef, xs), "--", color="grey")
        acc_label = "R\u00b2" if acc == "R2" else "RMSE"
        ax.set_xlabel(var.replace("_", " ") + " (\u00b0C)")
        ax.set_ylabel(acc_label if acc == "R2" else "RMSE (\u00b0C)")
        ax.set_title(f"{var.replace('_', ' ')} vs {acc_label}: r = {row['Pearson_r']:.3f}, p = {row['Pearson_p']:.3f}")
        ax.grid(alpha=0.3)
    _save(fig, path, dpi)


def rmse_bars(table5, names, methods, path, dpi):
    fig, ax = plt.subplots(figsize=(13, 6))
    xs, width = np.arange(len(names)), 0.2
    for k, method in enumerate(methods):
        ax.bar(xs + (k - 1.5) * width, table5.loc[names, method], width=width, label=method)
    ax.set_xticks(xs)
    ax.set_xticklabels(names, rotation=20)
    ax.set_ylabel("Test-period RMSE (\u00b0C)")
    ax.set_title("RMSE on the 2023\u20132024 test period by method")
    ax.grid(axis="y", alpha=0.3)
    ax.legend(loc="center left", bbox_to_anchor=(1.01, 0.5), frameon=False)
    _save(fig, path, dpi)
