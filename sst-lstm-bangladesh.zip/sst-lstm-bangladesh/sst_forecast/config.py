"""Settings used in the paper (Section 2.3 and Table 2)."""

# (file code, name used in the paper), in the order of the paper's tables
STATIONS = [
    ("SaintMartins", "Saint Martin's Island"),
    ("Teknaf", "Teknaf"),
    ("CoxsBazar", "Cox's Bazar"),
    ("Kutubdia", "Kutubdia"),
    ("Kuakata", "Kuakata"),
    ("DublarChar", "Dublar Char"),
    ("NijhumDwip", "Nijhum Dwip"),
]

# LSTM configuration (fixed a priori, not tuned)
LOOK_BACK = 60          # months, i.e. five annual cycles
UNITS = 64
LEARNING_RATE = 0.001   # Adam default
EPOCHS = 100
BATCH_SIZE = 12         # one year of monthly samples
SEED = 42

# Chronological split, defined by the month being predicted
TRAIN_END = "2021-12-01"
VAL = ("2022-01-01", "2022-12-01")    # used only to monitor training
TEST = ("2023-01-01", "2024-12-01")

# Recursive continuation beyond the observed record (January 2025 onwards)
FORECAST_MONTHS = 120
