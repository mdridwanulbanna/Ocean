"""Loading the station series and building the input windows."""
import os

import numpy as np
import pandas as pd

N_DAYS = 9132     # 1 January 2000 to 31 December 2024
N_MONTHS = 300


def load_monthly_sst(data_dir, code):
    """Read sst_<code>.csv (daily SST in deg C) and return monthly means for 2000-2024."""
    df = pd.read_csv(os.path.join(data_dir, f"sst_{code}.csv"), parse_dates=["time"])
    daily = df.set_index("time")["SST_C"].sort_index().loc["2000-01-01":"2024-12-31"]
    if len(daily) != N_DAYS or daily.isna().any() or daily.index.duplicated().any():
        raise ValueError(f"{code}: expected {N_DAYS} complete daily values for 2000-2024, got {len(daily)} "
                         f"({int(daily.isna().sum())} missing, {int(daily.index.duplicated().sum())} duplicated)")
    monthly = daily.resample("MS").mean()
    if len(monthly) != N_MONTHS or monthly.isna().any():
        raise ValueError(f"{code}: expected {N_MONTHS} complete monthly means, got {len(monthly)}")
    return monthly


def make_windows(values, dates, look_back):
    """Pair every month with the `look_back` observed months that precede it."""
    X, y, targets = [], [], []
    for i in range(look_back, len(values)):
        X.append(values[i - look_back:i])
        y.append(values[i])
        targets.append(dates[i])
    return np.array(X).reshape(-1, look_back, 1), np.array(y), pd.DatetimeIndex(targets)
