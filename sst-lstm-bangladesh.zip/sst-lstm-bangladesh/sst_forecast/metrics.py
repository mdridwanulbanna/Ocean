"""Accuracy metrics, station climatology and the variability-accuracy correlations."""
import numpy as np
import pandas as pd
from scipy.stats import pearsonr, spearmanr
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score


def scores(obs, pred):
    mse = mean_squared_error(obs, pred)
    return dict(MSE=mse, RMSE=np.sqrt(mse), MAE=mean_absolute_error(obs, pred), R2=r2_score(obs, pred))


def climatology_summary(monthly):
    """Mean, range, SD and seasonal amplitude of the full 2000-2024 monthly record."""
    cycle = monthly.groupby(monthly.index.month).mean()
    return dict(Mean=monthly.mean(), Min=monthly.min(), Max=monthly.max(),
                SD=monthly.std(), Seasonal_amplitude=cycle.max() - cycle.min())


def variability_correlations(clim_df, lstm_df):
    """Pearson and Spearman correlations between station variability and LSTM accuracy (n = 7)."""
    merged = clim_df.merge(lstm_df, on="Station")
    rows = []
    for var in ["SD", "Seasonal_amplitude"]:
        for acc in ["RMSE", "R2"]:
            r, p = pearsonr(merged[var], merged[acc])
            rho, p_s = spearmanr(merged[var], merged[acc])
            rows.append(dict(Relationship=f"{var} vs {acc}", Pearson_r=r, Pearson_p=p,
                             Spearman_rho=rho, Spearman_p=p_s))
    return pd.DataFrame(rows), merged
