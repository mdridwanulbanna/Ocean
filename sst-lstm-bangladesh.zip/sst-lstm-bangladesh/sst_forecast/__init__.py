"""Station-specific LSTM forecasting of monthly SST along the Bangladesh coast."""

__version__ = "1.0.0"
