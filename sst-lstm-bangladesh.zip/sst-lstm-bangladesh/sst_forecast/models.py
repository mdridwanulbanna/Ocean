"""The LSTM model and its reproducibility settings."""
import os
import random

import numpy as np
import tensorflow as tf

from .config import LEARNING_RATE, LOOK_BACK, UNITS


def set_seed(seed, deterministic=True):
    os.environ["PYTHONHASHSEED"] = str(seed)
    random.seed(seed)
    np.random.seed(seed)
    tf.keras.utils.set_random_seed(seed)
    if deterministic:
        try:
            tf.config.experimental.enable_op_determinism()
        except Exception:   # not available in older TensorFlow releases
            pass


def build_lstm():
    """One stateless LSTM layer (Keras defaults, no dropout) and one dense output unit."""
    model = tf.keras.Sequential([
        tf.keras.Input(shape=(LOOK_BACK, 1)),
        tf.keras.layers.LSTM(UNITS),
        tf.keras.layers.Dense(1),
    ])
    model.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=LEARNING_RATE), loss="mse")
    return model


def recursive_forecast(model, last_window, n_months):
    """Feed each prediction back as the newest input. Used only beyond the observed record."""
    window = last_window.reshape(1, -1, 1)
    out = []
    for _ in range(n_months):
        nxt = float(model(window, training=False)[0, 0])
        out.append(nxt)
        window = np.concatenate([window[:, 1:, :], [[[nxt]]]], axis=1)
    return np.array(out)
