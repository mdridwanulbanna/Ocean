"""Statistical baselines, evaluated on the same test months as the LSTM."""
import numpy as np
from statsmodels.tsa.statespace.sarimax import SARIMAX

from .config import TEST, TRAIN_END, VAL


def persistence(monthly):
    """Forecast each test month with the observed value of the month before."""
    return monthly.shift(1).loc[TEST[0]:TEST[1]].values


def climatology(monthly):
    """Calendar-month means of the training period (2000-2021)."""
    train = monthly.loc[:TRAIN_END]
    means = train.groupby(train.index.month).mean()
    return np.array([means[t.month] for t in monthly.loc[TEST[0]:TEST[1]].index])


def sarima_one_step(monthly, order=(1, 1, 1), seasonal_order=(1, 1, 1, 12)):
    """SARIMA fitted on 2000-2021 with parameters then held fixed.

    The 2022 observations update the model state (no re-estimation). Each test month is then
    forecast one step ahead and its observed value is appended before the next forecast, so
    SARIMA sees exactly the same information as the LSTM.
    Returns the forecasts and whether the maximum-likelihood fit converged.
    """
    fit = SARIMAX(monthly.loc[:TRAIN_END].values, order=order, seasonal_order=seasonal_order,
                  enforce_stationarity=False, enforce_invertibility=False).fit(disp=False)
    state = fit.append(monthly.loc[VAL[0]:VAL[1]].values, refit=False)
    preds = []
    for obs in monthly.loc[TEST[0]:TEST[1]].values:
        preds.append(state.forecast(1)[0])
        state = state.append([obs], refit=False)
    return np.array(preds), bool(fit.mle_retvals.get("converged", True))
