# Data

Put the seven station files here, named `sst_<Station>.csv`:

`sst_SaintMartins.csv`, `sst_Teknaf.csv`, `sst_CoxsBazar.csv`, `sst_Kutubdia.csv`,
`sst_Kuakata.csv`, `sst_DublarChar.csv`, `sst_NijhumDwip.csv`

Each file holds the daily series of one station from 1 January 2000 to 31 December 2024
(9,132 rows) with these columns:

| column | meaning |
|---|---|
| `time` | date (YYYY-MM-DD) |
| `latitude`, `longitude` | centre of the grid cell used for the station |
| `SST_C` | daily SST in °C |

The series come from the ESA SST CCI and C3S reprocessed sea surface temperature analyses
(Copernicus Marine product SST_GLO_SST_L4_REP_OBSERVATIONS_010_024, variable `analysed_sst`,
https://doi.org/10.48670/moi-00169). For each station the nearest 0.05° grid cell was taken and
converted from kelvin to °C. Grid-cell centres:

| Station | Latitude (°N) | Longitude (°E) |
|---|---|---|
| Saint Martin's Island | 20.625 | 92.325 |
| Teknaf | 20.825 | 92.325 |
| Cox's Bazar | 21.425 | 91.925 |
| Kutubdia | 21.825 | 91.825 |
| Kuakata | 21.775 | 90.175 |
| Dublar Char | 21.725 | 89.525 |
| Nijhum Dwip | 22.125 | 91.025 |

This study has been conducted using E.U. Copernicus Marine Service Information.
